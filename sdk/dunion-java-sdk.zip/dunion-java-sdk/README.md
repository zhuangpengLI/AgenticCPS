# 滴滴联盟 openAPI java-sdk

前期准备
```
//下载项目
git clone git@git.xiaojukeji.com:ut/dunion-openapi-sdk.git
cd dunion-java-sdk

//编译打包  
mvn clean assembly:assembly -Dmaven.test.skip=true

//server端pom文件
 <dependency>
   <groupId>org.dunion</groupId>
   <artifactId>dunion-java-sdk</artifactId>
   <version>1.2</version>
   <scope>system</scope>
   <systemPath>/"jar包所在路径"/dunion-java-sdk.jar</systemPath>
</dependency>   

//sdk中日志使用了slf4j日志接口，内部未提供默认的日志实现类，建议服务端引入，保证sdk日志可以正常打印，方便定位问题。     

```
使用方法  
```
//初始化配置（设置全局超时时间）
DunionClientConfig config = new DunionClientConfig.Builder().appKey("你的appKey").accessKey("你的accessKey").timeout(3*1000).build();

//使用DunionClientConfig创建Client
UnionClient unionClient = DunionClientFactory.build(config).getUnionClient();

//调用接口 （可设置单个接口的超时时间；传0时sdk会使用全局超时时间）
Result<LinkResponse> res = unionClient.GenerateH5Link(8303, 6868462090393422076L, "自定义sourceId", 2*1000);
if(res != null && res.isSuccess() && res.getModel() != null){
    System.out.println("=======Result<LinkResponse>======");
    System.out.println(res.getModel().getData().getAppId());
    System.out.println(res.getModel().getData().getAppSource());
    System.out.println(res.getModel().getData().getDsi());
    System.out.println(res.getModel().getData().getLink());
}
        
```

函数一览  

| 函数原型                                                                                                                    | 用途                            |
|-------------------------------------------------------------------------------------------------------------------------|-------------------------------|
| Result<`LinkResponse`> generateH5Link(long activityId, long promotionId, String sourceId, int timeout);                 | 生成h5推广链接                      |
| Result<`LinkResponse`> generateMiniLink(long activityId, long promotionId, String sourceId, int timeout);               | 生成小程序页面推广路径                   |  
| Result<`QrCodeResponse`> generateH5Code(String dsi, String sourceId, int timeout);                                      | 生成h5二维码，需先取链得到dsi             |
| Result<`QrCodeResponse`> generateMiniCode(String dsi, String sourceId, int timeout);                                    | 生成小程序太阳码，需先取链得到dsi            |
| Result<`PosterResponse`> generatePoster(String dsi, String sourceId, int timeout);                                      | 生成推广海报，需先取链得到dsi              |
| Result<`ExchangePwdResponse`> generateCouponPwd(long activityId, long promotionId, String sourceId, int timeout);       | 生成券码                          |
| Result<`QrCodeResponse`> generateH5CodeDirectly(long activityId, long promotionId, String sourceId, int timeout);       | 直接生成h5推广二维码，会内置请求一次取链接口       |
| Result<`QrCodeResponse`> generateMiniCodeDirectly(long activityId, long promotionId, String sourceId, int timeout) ;    | 直接生成小程序推广太阳码，会内置请求一次取链接口      |
| Result<`PosterResponse`> GeneratePosterDirectly(long activityId, long promotionId, String sourceId, int timeout);       | 直接生成推广海报，会内置请求一次取链接口          |
| Result<`OrderResponse`> queryOrderList(long startTime, long endTime, OrderType type, int page, int size, int timeout) ; | 查询订单列表                        |
| Result<`OrderCallbackResponse`> mockOrderCallback(String dsi, String sourceId, OrderMockType type, int timeout) ;       | 模拟订单回调，需先取链得到 dsi; 需在后台配置回调地址 |
| Result<`OrderSelfQueryResponse`> selfQueryOrder(String orderId, int timeout) ;                                          | 订单归因问题自查询                     |

