package cn.didi.union.client;

import cn.didi.union.models.DunionClientConfig;

import java.util.TreeMap;

public interface BasicClient {

    /**
     * 发起http post请求
     *
     * @param dunionClientConfig 配置
     * @param urlPath 请求的url
     * @param timeout 超时时间
     * @param params 请求参数
     * @return 返回值
     */
    String doPost(DunionClientConfig dunionClientConfig, String urlPath, int timeout, TreeMap<String, Object> params);

    /**
     * 发起http get请求
     *
     * @param dunionClientConfig 配置
     * @param urlPath 请求的url
     * @param timeout 超时时间
     * @param params 请求参数
     * @return 返回值
     */
    String doGet(DunionClientConfig dunionClientConfig, String urlPath, int timeout, TreeMap<String, Object> params);

}


