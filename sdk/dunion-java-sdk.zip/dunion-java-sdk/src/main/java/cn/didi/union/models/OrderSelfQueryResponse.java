package cn.didi.union.models;


public class OrderSelfQueryResponse extends BaseModel{
    public EstimateQueryData data;

    public OrderSelfQueryResponse(String errmsg, long errno, String traceid, EstimateQueryData data) {
        super(errmsg, errno, traceid);
        this.data = data;
    }

    public EstimateQueryData getData() {
        return data;
    }

    public void setData(EstimateQueryData data) {
        this.data = data;
    }
}
