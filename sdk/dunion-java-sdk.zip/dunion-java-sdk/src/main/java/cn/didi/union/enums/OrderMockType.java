package cn.didi.union.enums;

public enum OrderMockType {
    //支付
    MockPay("mock_pay",0),
    //付款
    MockRefund("mock_refund",1);

    public final String name;
    public final int value;

    OrderMockType(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}
