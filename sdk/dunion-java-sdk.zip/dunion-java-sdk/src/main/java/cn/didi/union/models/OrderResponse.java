package cn.didi.union.models;


public class OrderResponse extends BaseModel{
    public OrderData data;

    public OrderResponse(String errmsg, long errno, String traceid, OrderData data) {
        super(errmsg, errno, traceid);
        this.data = data;
    }

    public OrderData getData() {
        return data;
    }

    public void setData(OrderData data) {
        this.data = data;
    }
}
