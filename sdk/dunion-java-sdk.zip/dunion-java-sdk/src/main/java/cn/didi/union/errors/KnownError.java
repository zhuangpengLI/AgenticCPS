package cn.didi.union.errors;

import cn.didi.union.enums.ErrorCodeEnum;

public class KnownError extends ErrorBase{

    public KnownError(String message) {
        this.setCode(ErrorCodeEnum.KNOWN_ERROR.getValue());
        this.setMessage(message);
    }

}
