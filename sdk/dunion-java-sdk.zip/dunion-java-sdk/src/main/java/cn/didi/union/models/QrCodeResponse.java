package cn.didi.union.models;

public class QrCodeResponse extends BaseModel{
    public QrCodeData data;

    public QrCodeResponse(String errmsg, long errno, String traceid, QrCodeData data) {
        super(errmsg, errno, traceid);
        this.data = data;
    }

    public QrCodeData getData() {
        return data;
    }

    public void setData(QrCodeData data) {
        this.data = data;
    }
}
