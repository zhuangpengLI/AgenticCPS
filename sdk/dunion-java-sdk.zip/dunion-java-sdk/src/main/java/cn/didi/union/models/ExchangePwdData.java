package cn.didi.union.models;


import com.google.gson.annotations.SerializedName;

public class ExchangePwdData {

    //生成的兑换码
    @SerializedName("exchange_pwd")
    public String exchangePwd;

    public String getExchangePwd() {
        return exchangePwd;
    }

    public void setExchangePwd(String exchangePwd) {
        this.exchangePwd = exchangePwd;
    }
}
