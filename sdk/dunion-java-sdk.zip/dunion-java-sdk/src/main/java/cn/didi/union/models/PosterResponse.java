package cn.didi.union.models;

public class PosterResponse extends BaseModel{
    public PosterData data;

    public PosterResponse(String errmsg, long errno, String traceid, PosterData data) {
        super(errmsg, errno, traceid);
        this.data = data;
    }

    public PosterData getData() {
        return data;
    }

    public void setData(PosterData data) {
        this.data = data;
    }


}
