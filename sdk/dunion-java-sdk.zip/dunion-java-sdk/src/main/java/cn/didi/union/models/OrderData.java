package cn.didi.union.models;


import com.google.gson.annotations.SerializedName;

import java.util.List;

public class OrderData {

    // 总数量
    public int total;

    @SerializedName("order_list")
    public List<OrderDetail> orderList;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<OrderDetail> getOrderList() {
        return orderList;
    }

    public void setOrderList(List<OrderDetail> orderList) {
        this.orderList = orderList;
    }
}
