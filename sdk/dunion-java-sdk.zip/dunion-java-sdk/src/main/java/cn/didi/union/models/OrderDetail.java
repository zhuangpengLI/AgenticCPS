package cn.didi.union.models;


import com.google.gson.annotations.SerializedName;


public class OrderDetail {

    // 标题
    public String title;

    // 订单id
    @SerializedName("order_id")
    public String orderId;

    // 业务线id
    @SerializedName("product_id")
    public String productId;

    // 支付金额，单位：分
    @SerializedName("pay_price")
    public long payPrice;

    // 支付时间，秒级时间戳
    @SerializedName("pay_time")
    public long payTime;

    // 退款金额，单位：分
    @SerializedName("refund_price")
    public long refundPrice;

    // 退款时间，秒级时间戳
    @SerializedName("refund_time")
    public long refundTime;

    // CPA返佣金额，单位：分
    @SerializedName("cpa_profit")
    public long cpaProfit;

    // CPS返佣金额，单位：分
    @SerializedName("cps_profit")
    public long cpsProfit;

    // CPA类型
    @SerializedName("cpa_type")
    public String cpaType;

    // 推送状态: 1.已预估归因  2.预估订单已推送 3.预估订单推送失败  4.结算提交  5.结算提交失败 6.结算取消  7.结算成功  8.结算失败
    public int status;

    // 推广位ID
    @SerializedName("promotion_id")
    public long promotionId;

    // 来源ID
    @SerializedName("source_id")
    public String sourceId;

    // 是否被风控
    @SerializedName("is_risk")
    public int isRisk;

    // 下单用户openUID
    @SerializedName("open_uid")
    public String openUid;

    // 订单状态 `2`:已付款 `8`:已退款
    @SerializedName("order_status")
    public int orderStatus;

    // 失败原因
    @SerializedName("fail_reason")
    public String failReason;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public long getPayPrice() {
        return payPrice;
    }

    public void setPayPrice(long payPrice) {
        this.payPrice = payPrice;
    }

    public long getPayTime() {
        return payTime;
    }

    public void setPayTime(long payTime) {
        this.payTime = payTime;
    }

    public long getRefundPrice() {
        return refundPrice;
    }

    public void setRefundPrice(long refundPrice) {
        this.refundPrice = refundPrice;
    }

    public long getRefundTime() {
        return refundTime;
    }

    public void setRefundTime(long refundTime) {
        this.refundTime = refundTime;
    }

    public long getCpaProfit() {
        return cpaProfit;
    }

    public void setCpaProfit(long cpaProfit) {
        this.cpaProfit = cpaProfit;
    }

    public long getCpsProfit() {
        return cpsProfit;
    }

    public void setCpsProfit(long cpsProfit) {
        this.cpsProfit = cpsProfit;
    }

    public String getCpaType() {
        return cpaType;
    }

    public void setCpaType(String cpaType) {
        this.cpaType = cpaType;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public long getPromotionId() {
        return promotionId;
    }

    public void setPromotionId(long promotionId) {
        this.promotionId = promotionId;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public int getIsRisk() {
        return isRisk;
    }

    public void setIsRisk(int isRisk) {
        this.isRisk = isRisk;
    }

    public String getOpenUid() {
        return openUid;
    }

    public void setOpenUid(String openUid) {
        this.openUid = openUid;
    }

    public int getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(int orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getFailReason() {
        return failReason;
    }

    public void setFailReason(String failReason) {
        this.failReason = failReason;
    }
}
