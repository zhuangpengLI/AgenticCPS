package cn.didi.union.models;

import com.google.gson.annotations.SerializedName;

public class EstimateSuccessData {

    // 推广成功时间 2022-01-10 10:30:00
    @SerializedName("estimate_time")
    public String estimateTime;

    // 推广渠道
    @SerializedName("estimate_channel")
    public String estimateChannel;

    // 领券状态 `1`:成功 `2`:失败
    @SerializedName("receive_status")
    public int receiveStatus;

    // 领券时间 2022-01-10 10:00:00
    @SerializedName("receive_time")
    public String receiveTime;

    // 业务线名称
    @SerializedName("scene_name")
    public String sceneName;


    public String getEstimateTime() {
        return estimateTime;
    }

    public void setEstimateTime(String estimateTime) {
        this.estimateTime = estimateTime;
    }

    public String getEstimateChannel() {
        return estimateChannel;
    }

    public void setEstimateChannel(String estimateChannel) {
        this.estimateChannel = estimateChannel;
    }

    public int getReceiveStatus() {
        return receiveStatus;
    }

    public void setReceiveStatus(int receiveStatus) {
        this.receiveStatus = receiveStatus;
    }

    public String getReceiveTime() {
        return receiveTime;
    }

    public void setReceiveTime(String receiveTime) {
        this.receiveTime = receiveTime;
    }

    public String getSceneName() {
        return sceneName;
    }

    public void setSceneName(String sceneName) {
        this.sceneName = sceneName;
    }
}
