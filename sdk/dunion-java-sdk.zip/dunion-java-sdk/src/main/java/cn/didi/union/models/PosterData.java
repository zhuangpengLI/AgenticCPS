package cn.didi.union.models;

import com.google.gson.annotations.SerializedName;


public class PosterData {
    //生成的海报链接
    @SerializedName("poster_link")
    public String posterLink;

    public String getPosterLink() {
        return posterLink;
    }

    public void setPosterLink(String posterLink) {
        this.posterLink = posterLink;
    }
}
