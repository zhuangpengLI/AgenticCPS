package cn.didi.union.models;


import com.google.gson.annotations.SerializedName;

public class LinkData {

    //小程序appid
    @SerializedName("app_id")
    public String appId;

    //小程序原始ID
    @SerializedName("app_source")
    public String appSource;

    //实例ID，可通过此ID去生成海报或者二维码
    public String dsi;

    //生成的链接
    public String link;

    public LinkData(String appId, String appSource, String dsi, String link) {
        this.appId = appId;
        this.appSource = appSource;
        this.dsi = dsi;
        this.link = link;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppSource() {
        return appSource;
    }

    public void setAppSource(String appSource) {
        this.appSource = appSource;
    }

    public String getDsi() {
        return dsi;
    }

    public void setDsi(String dsi) {
        this.dsi = dsi;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
