package cn.didi.union.errors;

import cn.didi.union.enums.ErrorCodeEnum;

public class SystemError extends ErrorBase{

    public SystemError(String message) {
        this.setCode(ErrorCodeEnum.SERVER_ERROR.getValue());
        this.setMessage(message);
    }

}
