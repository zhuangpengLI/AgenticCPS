package cn.didi.union.auth;

import java.util.UUID;

public class Uuid {
    public static String getUUID() {
        String id;
        UUID uuid = UUID.randomUUID();
        id = uuid.toString();
        //去掉随机ID的短横线
        id = id.replace("-", "");
        return id;
    }
}
