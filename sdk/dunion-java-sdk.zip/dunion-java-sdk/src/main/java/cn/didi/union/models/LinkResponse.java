package cn.didi.union.models;


public class LinkResponse extends BaseModel{

    public LinkData data;

    public LinkResponse(String errmsg, long errno, String traceid, LinkData data) {
        super(errmsg, errno, traceid);
        this.data = data;
    }

    public LinkData getData() {
        return data;
    }

    public void setData(LinkData data) {
        this.data = data;
    }
}
