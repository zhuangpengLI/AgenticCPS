package cn.didi.union.errors;

import cn.didi.union.enums.ErrorCodeEnum;

public class ParamError extends ErrorBase{

    public ParamError(String message) {
        this.setCode(ErrorCodeEnum.PARAM_ERROR.getValue());
        this.setMessage(message);
    }

}
