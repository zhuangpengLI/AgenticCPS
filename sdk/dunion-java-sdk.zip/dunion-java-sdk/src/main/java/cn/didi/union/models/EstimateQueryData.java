package cn.didi.union.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;


public class EstimateQueryData {
    // 推广成功列表
    @SerializedName("estimate_success_list")
    public List<EstimateSuccessData> estimateSuccessList;

    // 推广失败列表
    @SerializedName("estimate_fail_list")
    public List<EstimateFailData> estimateFailList;

    public List<EstimateSuccessData> getEstimateSuccessList() {
        return estimateSuccessList;
    }

    public void setEstimateSuccessList(List<EstimateSuccessData> estimateSuccessList) {
        this.estimateSuccessList = estimateSuccessList;
    }

    public List<EstimateFailData> getEstimateFailList() {
        return estimateFailList;
    }

    public void setEstimateFailList(List<EstimateFailData> estimateFailList) {
        this.estimateFailList = estimateFailList;
    }
}
