package cn.didi.union.client;

import cn.didi.union.enums.OrderMockType;
import cn.didi.union.enums.OrderType;
import cn.didi.union.models.*;


public interface UnionClient extends BasicClient {
    /**
     * 生成h5推广链接
     * @param activityId 活动id
     * @param promotionId 推广位id
     * @param sourceId sourceId
     * @param timeout 超时时间
     * @return 返回值
     */
    Result<LinkResponse> generateH5Link(long activityId, long promotionId, String sourceId, int timeout);

    /**
     * 生成小程序页面推广路径
     * @param activityId 活动id
     * @param promotionId 推广位id
     * @param sourceId sourceId
     * @param timeout 超时时间
     * @return 返回值
     */
    Result<LinkResponse> generateMiniLink(long activityId, long promotionId, String sourceId, int timeout);

    /**
     * 生成h5二维码，需先取链得到dsi
     * @param dsi dsi
     * @param sourceId sourceId
     * @param timeout 超时时间
     * @return 返回值
     */
    Result<QrCodeResponse> generateH5Code(String dsi, String sourceId, int timeout);

    /**
     * 生成小程序太阳码，需先取链得到dsi
     * @param dsi dsi
     * @param sourceId sourceId
     * @param timeout 超时时间
     * @return 返回值
     */
    Result<QrCodeResponse> generateMiniCode(String dsi, String sourceId, int timeout);

    /**
     * 生成推广海报，需先取链得到dsi
     * @param dsi dsi
     * @param sourceId sourceId
     * @param timeout 超时时间
     * @return 返回值
     */
    Result<PosterResponse> generatePoster(String dsi, String sourceId, int timeout);

    /**
     * 直接生成h5推广二维码，会内置请求一次取链接口
     * @param activityId 活动id
     * @param promotionId 推广位id
     * @param sourceId sourceId
     * @param timeout 超时时间
     * @return 返回值
     */
    Result<QrCodeResponse> generateH5CodeDirectly(long activityId, long promotionId, String sourceId, int timeout);

    /**
     * 直接生成小程序推广太阳码，会内置请求一次取链接口
     * @param activityId 活动id
     * @param promotionId 推广位id
     * @param sourceId sourceId
     * @param timeout 超时时间
     * @return 返回值
     */
    Result<QrCodeResponse> generateMiniCodeDirectly(long activityId, long promotionId, String sourceId, int timeout) ;

    /**
     * 直接生成推广海报，会内置请求一次取链接口
     * @param activityId 活动id
     * @param promotionId 推广位id
     * @param sourceId sourceId
     * @param timeout 超时时间
     * @return 返回值
     */
    Result<PosterResponse> generatePosterDirectly(long activityId, long promotionId, String sourceId, int timeout);

    /**
     * 生成券码
     * @param activityId 活动id
     * @param promotionId 推广位id
     * @param sourceId sourceId
     * @param timeout 超时时间
     * @return 返回值
     */
    Result<ExchangePwdResponse> generateCouponPwd(long activityId, long promotionId, String sourceId, int timeout);

    /**
     * 查询订单列表
     *
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param type 类型
     * @param page 起始页面
     * @param size 每页查询数量
     * @param timeout 超时时间
     * @return 返回值
     */
    Result<OrderResponse> queryOrderList(long startTime, long endTime, OrderType type, int page, int size, int timeout) ;

    /**
     * 模拟订单回调：需先取链得到 dsi
     * @param dsi dsi
     * @param sourceId sourceId
     * @param type mock类型
     * @param timeout 超时时间
     * @return 返回值
     */
    Result<OrderCallbackResponse> mockOrderCallback(String dsi, String sourceId, OrderMockType type, int timeout) ;

    /**
     * 订单归因问题自助查询
     * @param orderId 订单id
     * @param timeout 超时时间
     * @return  返回值
     */
    Result<OrderSelfQueryResponse> selfQueryOrder(String orderId, int timeout) ;

}
