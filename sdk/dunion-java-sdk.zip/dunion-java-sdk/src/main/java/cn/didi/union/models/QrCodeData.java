package cn.didi.union.models;

import com.google.gson.annotations.SerializedName;


public class QrCodeData {
    //生成的二维码链接
    @SerializedName("code_link")
    public String codeLink;

    public String getCodeLink() {
        return codeLink;
    }

    public void setCodeLink(String codeLink) {
        this.codeLink = codeLink;
    }
}
