package cn.didi.union.models;


public class ExchangePwdResponse extends BaseModel{

    public ExchangePwdData data;

    public ExchangePwdResponse(String errmsg, long errno, String traceid, ExchangePwdData data) {
        super(errmsg, errno, traceid);
        this.data = data;
    }

    public ExchangePwdData getData() {
        return data;
    }

    public void setData(ExchangePwdData data) {
        this.data = data;
    }
}
