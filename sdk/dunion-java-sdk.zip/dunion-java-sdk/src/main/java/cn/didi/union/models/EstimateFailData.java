package cn.didi.union.models;

import com.google.gson.annotations.SerializedName;


public class EstimateFailData {
    // 失败原因
    @SerializedName("fail_reason")
    public String failReason;

    // 业务线名称
    @SerializedName("scene_name")
    public String sceneName;

    public String getFailReason() {
        return failReason;
    }

    public void setFailReason(String failReason) {
        this.failReason = failReason;
    }

    public String getSceneName() {
        return sceneName;
    }

    public void setSceneName(String sceneName) {
        this.sceneName = sceneName;
    }
}
