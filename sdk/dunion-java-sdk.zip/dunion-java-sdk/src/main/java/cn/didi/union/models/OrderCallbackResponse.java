package cn.didi.union.models;


public class OrderCallbackResponse extends BaseModel{
    public OrderCallbackData data;


    public OrderCallbackResponse(String errmsg, long errno, String traceid, OrderCallbackData data) {
        super(errmsg, errno, traceid);
        this.data = data;
    }

    public OrderCallbackData getData() {
        return data;
    }

    public void setData(OrderCallbackData data) {
        this.data = data;
    }
}
