package cn.didi.union.errors;

import cn.didi.union.enums.ErrorCodeEnum;

public class BizError extends ErrorBase{

    public BizError(String message) {
        this.setCode(ErrorCodeEnum.BIZ_ERROR.getValue());
        this.setMessage(message);
    }

}
