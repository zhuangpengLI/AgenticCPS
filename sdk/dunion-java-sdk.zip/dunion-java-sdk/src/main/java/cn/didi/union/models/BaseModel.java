package cn.didi.union.models;

public class BaseModel {
    public String errmsg;
    public long errno;
    public String traceid;

    public BaseModel(String errmsg, long errno, String traceid) {
        this.errmsg = errmsg;
        this.errno = errno;
        this.traceid = traceid;
    }

    public String getErrmsg() {
        return errmsg;
    }

    public long getErrno() {
        return errno;
    }
    
    public String getTraceid() {
        return traceid;
    }

}
