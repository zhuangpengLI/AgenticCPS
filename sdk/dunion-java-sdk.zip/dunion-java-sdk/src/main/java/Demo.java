import cn.didi.union.client.DunionClientFactory;
import cn.didi.union.client.UnionClient;
import cn.didi.union.models.*;

public class Demo {

    public static void main(String[] args)  {
        //初始化配置
        DunionClientConfig config = new DunionClientConfig.Builder().appKey("你的appKey").accessKey("你的accessKey").timeout(3*1000).build();

        //使用DunionClientConfig创建Client
        UnionClient unionClient = DunionClientFactory.build(config).getUnionClient();

        //调用接口
        //取链
        Result<LinkResponse> res = unionClient.generateH5Link(8303, 6868462090393422076L, "自定义sourceId", 0);
        if(res != null && res.isSuccess() && res.getModel() != null){
            System.out.println("====== Result<LinkResponse>======");
            System.out.println(res.getModel().getData().getAppId());
            System.out.println(res.getModel().getData().getAppSource());
            System.out.println(res.getModel().getData().getDsi());
            System.out.println(res.getModel().getData().getLink());
        }

        //订单自助查询
        System.out.println("============");
        Result<OrderSelfQueryResponse> res2 = unionClient.selfQueryOrder("352719112233507", 0);
        if(res2 != null && res2.isSuccess() && res2.getModel() != null){
            System.out.println("====== Result<OrderSelfQueryResponse>======");

            System.out.println(res2.getModel().getTraceid());
            System.out.println(res2.getModel().getErrno());
            System.out.println(res2.getModel().getErrmsg());
            if(res2.getModel().getData().getEstimateSuccessList() != null){
                System.out.println(res2.getModel().getData().getEstimateSuccessList().get(0).getEstimateChannel());
            }
            if(res2.getModel().getData().getEstimateFailList() != null){
                System.out.println(res2.getModel().getData().getEstimateFailList().get(0).getFailReason());
            }
        }

    }

}
